import { ha as _sfc_main } from "./index-Bpsc-Tmx.js";
export {
  _sfc_main as default
};
