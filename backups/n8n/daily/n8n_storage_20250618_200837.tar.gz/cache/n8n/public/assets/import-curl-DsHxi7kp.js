import { B as createEventBus } from "./index-Bpsc-Tmx.js";
const importCurlEventBus = createEventBus();
export {
  importCurlEventBus as i
};
