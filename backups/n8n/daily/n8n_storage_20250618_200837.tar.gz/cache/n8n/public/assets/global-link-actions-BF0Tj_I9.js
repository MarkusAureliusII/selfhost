import { B as createEventBus } from "./index-Bpsc-Tmx.js";
const globalLinkActionsEventBus = createEventBus();
export {
  globalLinkActionsEventBus as g
};
