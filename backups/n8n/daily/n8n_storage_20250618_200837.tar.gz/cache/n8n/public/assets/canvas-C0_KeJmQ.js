import { B as createEventBus } from "./index-Bpsc-Tmx.js";
const canvasEventBus = createEventBus();
export {
  canvasEventBus as c
};
